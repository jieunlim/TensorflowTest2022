#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 17:42:24 2019

To students

@author: a.iliev
This program depicts the usage of constant and placeholders in tensorflow
and creates a graph
"""
import tensorflow as tf

# Make the code compatible with tf.v1 and run a graph, where you:
#   1. disable eager mode then:
#   2. create a constant 'a=6' of type int32 and name it 'A' on the graph
#   3. use 'b' as a placeholder of type int32, shape 3, and name it 'B' on the graph
#   4. multiply 'a' and 'b' and name the Op 'Multiplication' for the graph
#   5. run the graph in a Session, saving it to a ./logs folder
#   6. where you supply 'b' with some numbers creating a dictionary
#   7. feed the dictionary from 6. and run 'c' to print the final result
#   8. show the graph using Tensorboard