#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Oct 12 19:33:56 2019

@author: Alexander Iliev
"""

import tensorflow.compat.v1 as tf
from tensorflow.python.ops import gen_math_ops
import numpy as np

''' 1. Eager Execution ''' # Restart kernel and run:
tf.enable_eager_execution() # Eager execution enabled 

dZ = np.array([[ 0.1,  0.1,  0.1,  0.1,  0.1,  0.1, -0.9,  0.1,  0.1,  0.1]])
FC_W = np.array([[1., 1., 1., 1., 1., 1., 1., 1., 1., 1.],
        [1., 1., 1., 1., 1., 1., 1., 1., 1., 1.],
        [1., 1., 1., 1., 1., 1., 1., 1., 1., 1.]])
a = gen_math_ops.mat_mul(dZ, FC_W, False, True)

print(a)

# ''' 2.Graph Execution ''' # Restart kernel and run:
# tf.disable_eager_execution() # Eager execution disabled 

# dZ = np.array([[ 0.1,  0.1,  0.1,  0.1,  0.1,  0.1, -0.9,  0.1,  0.1,  0.1]])

# FC_W = np.array([[1., 1., 1., 1., 1., 1., 1., 1., 1., 1.],
#         [1., 1., 1., 1., 1., 1., 1., 1., 1., 1.],
#         [1., 1., 1., 1., 1., 1., 1., 1., 1., 1.]])
# a = gen_math_ops.mat_mul(dZ, FC_W, False, True)

# sess = tf.InteractiveSession()
# print(str(sess.run(a)))
