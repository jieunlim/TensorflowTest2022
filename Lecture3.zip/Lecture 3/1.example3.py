#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Jul.11.2020
Type this code in class and explain line by line!
@author: a.iliev
This program depicts the usage of passing dictionary to a placeholder in TF
"""
import tensorflow as tf
g2= tf.Graph()         # define a default graph which is passed to session

with g2.as_default():  # use defined graph as default graph
    a = tf.compat.v1.placeholder(tf.float32)  # Declaring placeholder of type float
    b = a * 2
    
with tf.compat.v1.Session(graph=g2) as sess:
    dictionary = {a:[[1,2,3],[4,5,6]]}
    result = sess.run(b,feed_dict = dictionary)# passing dictionary to placeholder
    print(result)

sess.close()