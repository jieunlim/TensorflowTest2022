#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul 18 09:09:26 2020

@author: Alexander Iliev
"""

#Matrix Addition and Matrix Multiplication

import tensorflow as tf

g= tf.Graph() # A TensorFlow computation, represented as a dataflow graph.
with g.as_default(): #A default Graph is always registered, and accessible by calling
    matrix_one = tf.constant([[1,2,3], [4,5,6], [1,2,3]]) # Creates a constant tensor
    matrix_two = tf.constant([[1,2,3], [4,5,6], [1,2,3]])
    
    result_one = matrix_one + matrix_two
    result_two = tf.add(matrix_one, matrix_two)# Addition of matrix one and two, producing a + b
    result_three = tf.matmul(matrix_one, matrix_two) #Multiplies matrix one by matrix two,
                                                      #producing a * b.

sess = tf.compat.v1.Session(graph=g) #A class for running TensorFlow operations
#A Session object encapsulates the environment in which Operation 
#objects are executed, and Tensor objects are evaluated
result1 = sess.run(result_one)
print("The result one was:", result1)
result2 = sess.run(result_two)
print("The Result two Was:", result2)
result3 = sess.run(result_three)
print("The Result of matrix multiplication was :", result3)

