#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Oct 12 19:23:57 2019
Modified on Sat Jun 12 13:06:34 2021

When running on TF 2.0+ replace all 'tf.' with 'tf.compat.v1.'

!!! Restart Kernel with Eager execution OFF, before running this file !!!

Disable eager execution: tf.compat.v1.disable_eager_execution()
Check the status of eager mode using: tf.executing_eagerly()

@author: Alexander Iliev
"""

import tensorflow as tf 
tf.compat.v1.enable_eager_execution()
# create the graph
with tf.compat.v1.variable_scope('foo', reuse=tf.compat.v1.AUTO_REUSE):
    weights = tf.compat.v1.get_variable(name="W", shape=[2,3], initializer=tf.compat.v1.truncated_normal_initializer(stddev=0.01)) 
    biases = tf.compat.v1.get_variable(name="b", shape=[3], initializer=tf.compat.v1.zeros_initializer()) 
 
# add an Op to initialize global variables 
init_op = tf.compat.v1.global_variables_initializer() 
 
# launch the graph in a session 
with tf.compat.v1.Session() as sess: 
    # run the variable initializer 
    sess.run(init_op) 
    # now we can run our operations 
    W, b = sess.run([weights, biases]) 
    print('weights = {}'.format(W)) 
    print('biases = {}'.format(b)) 