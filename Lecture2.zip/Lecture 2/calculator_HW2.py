#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 17:42:24 2019
HW2
@author: Alexander Iliev
this program depicts working with classes.
calculator class performs basic addition subtraction multiplication and
division
"""
import tensorflow as tf
class calculator():
   
    def __init__(self,num1,num2): #initialize variables
        self.num1 = num1
        self.num2 = num2

    def multiply(self):
        g= tf.Graph() # define a default graph which is passed to session
        with g.as_default():
               
                    x1 = self.num1
                    x2 = self.num2
                    result = tf.multiply(x1, x2)
           
            # Multiply`:
            # Initialize Session and run `result`
                    with tf.compat.v1.Session(graph=g) as sess:
                      output = sess.run(result)
                      return output
    
    # Complete the code for: 
    # addition, subtraction, division:


oper = input("what operation ")
num1 = int(input("Enter num1 "))
num2 = int(input("Enter num2 "))

c = calculator(num1, num2) #instantiation
if(oper == "multiply"):
    print("Answer: ",c.multiply())
# Complete the code: print all results here...   
