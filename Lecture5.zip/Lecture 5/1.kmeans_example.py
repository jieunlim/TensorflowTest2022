# -*- coding: utf-8 -*-
## k-means algorithm
""" Alexander I. Iliev modified on March.03.2019

Intro: 
======
When working with k-means, the data in a training set does not need labels. 
As an unsupervised learning method, the algorithm builds clusters based on 
the data itself. """

import matplotlib.pyplot as plt
import numpy as np
import tensorflow.compat.v1 as tf

tf.disable_v2_behavior()

# Create aliases:
tf.sub = tf.subtract

points_n = 200
clusters_n = 6
iteration_n = 10

# 1. Let’s generate random data points with a uniform distribution and assign them 
#    to a 2D tensor constant. Then, randomly choose initial centroids from the set 
#    of data points:
points = tf.constant(np.random.uniform(0, 10, (points_n, 2)))
centroids = tf.Variable(tf.slice(tf.random_shuffle(points), [0, 0], [clusters_n, -1]))

# 2. Next we want to be able to do element-wise subtraction of points and centroids 
#    that are 2D tensors. Because the tensors have different shape, let’s expend points 
#    and centroids into 3 dimensions, which allows us to use the broadcasting feature of 
#    subtraction operation:
points_expanded = tf.expand_dims(points, 0)
centroids_expanded = tf.expand_dims(centroids, 1)

# 3. Then, calculate the distances between points and centroids and determine the 
#    cluster assignments:
distances = tf.reduce_sum(tf.square(tf.sub(points_expanded, centroids_expanded)), 2)
assignments = tf.argmin(distances, 0)

# 4. Next, we can compare each cluster with a cluster assignments vector, get points 
#    assigned to each cluster, and calculate mean values. These mean values are refined 
#    centroids, so let’s update the centroids variable with the new values:
means = []
for c in range(clusters_n):
    means.append(tf.reduce_mean( tf.gather(points, 
                tf.reshape(tf.where(tf.equal(assignments, c)),[1,-1])),reduction_indices=[1]))

new_centroids = tf.concat(means, 0)

update_centroids = tf.assign(centroids, new_centroids)
init = tf.global_variables_initializer()

# 5. Next we run the graph. For each iteration, we update the centroids and return 
#    their values along with the cluster assignments values:
with tf.Session() as sess:
  sess.run(init)
  for step in range(iteration_n):
    [_, centroid_values, points_values, assignment_values] = sess.run([update_centroids, centroids, points, assignments])

    # Plot the progress of centrod recalculation in each iteration:
    plt.scatter(points_values[:, 0], points_values[:, 1], c=assignment_values, s=50, alpha=0.5)
    plt.plot(centroid_values[:, 0], centroid_values[:, 1], 'kx', markersize=15)
    plt.pause(1)
    plt.clf()

# 6. We display the coordinates of the final centroids and a multi-colored 
#    scatter plot showing how the data points have been clustered: 
print("centroids" + "\n", centroid_values)

# 7. Finally, plot the final state of the system before exitting:
plt.scatter(points_values[:, 0], points_values[:, 1], c=assignment_values, s=50, alpha=0.5)
plt.plot(centroid_values[:, 0], centroid_values[:, 1], 'kx', markersize=15)
plt.pause(1)

# The data in a training set is grouped into clusters as the result of implementing 
# the k-means algorithm in TensorFlow.