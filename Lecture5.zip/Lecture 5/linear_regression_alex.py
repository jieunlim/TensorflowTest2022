## Linear regression example in "TF for Machine Intelligence" book
# Modified by Alexander I. Iliev - 06.10.2018 / 04.10.2021

# Linear regression:
import tensorflow.compat.v1 as tf
import pandas as pd
tf.disable_eager_execution()

W = tf.Variable(tf.zeros([2, 1]), name="weights")
b = tf.Variable(0., name="bias")

# Computing our model in a series of mathematical operations that we apply to our data:
def inference(X):
    return tf.matmul(X, W) + b

# Calculate loss over expected output:
def loss(X, Y):
    Y_predicted = tf.transpose(inference(X))
    return tf.reduce_sum(tf.squared_difference(Y, Y_predicted))

# Read input training data:
def inputs():
    weight_age = []
    blood_fat  = []
    data = pd.read_csv('blood_fat_data.csv')
    data.head(1)                # reads the first line
    rows = len(data)            # counts the number of rows in the file
    shape = data.shape          # shows the shape
    columns = (data.columns)    # shows the column titles
    weight = data[columns[0]]   # write entire column
    age = data[columns[1]]      # write entire column
    blood_fat_content = data[columns[2]]    # write entire column
    for k in range(rows):       # use loop to put it in the expected format
        weight_age.append([weight[k], age[k]])
        blood_fat.append(blood_fat_content[k],)

    return tf.to_float(weight_age), tf.to_float(blood_fat)

# Using training, we adjust the model parameters:
def train(total_loss):
    learning_rate = 0.000001 # try: 0.000006
    return tf.train.GradientDescentOptimizer(learning_rate).minimize(total_loss)

# We evaluate the resulting model:
def evaluate(sess, X, Y):
    print(sess.run(inference([[55., 40.]]))) # ~ 295 (but it is 303)
    print(sess.run(inference([[50., 70.]]))) # ~ 256 (other values not in table)
    print(sess.run(inference([[90., 20.]]))) # ~ 303 ( ... )
    print(sess.run(inference([[90., 70.]]))) # ~ 256 ( ... )

# Launch the graph in a session and run the training loop:
with tf.Session() as sess:

    tf.global_variables_initializer().run()

    X, Y = inputs()
    total_loss = loss(X, Y)
    train_op = train(total_loss)

    # Actual training loop:
    training_steps = 10000 # try: 50000
    for step in range(training_steps):
        sess.run([train_op])
        # See how the loss gets decremented thru training steps:
        if step % 1000 == 0:
            print("Epoch:", step, " loss: ", sess.run(total_loss))

    print("Final model W=", sess.run(W), "b=", sess.run(b))
    evaluate(sess, X, Y)

    sess.close()


